import json
import getpass
import pandas as pd
import tkinter as tk
from tkinter import filedialog
from openai import OpenAI


print("API 키를 붙여넣고 Enter를 누르세요.")
print("보안상 입력한 내용은 화면에 표시되지 않습니다.")

api_key = getpass.getpass("OpenAI API Key: ").strip()

if not api_key:
    raise ValueError("API 키가 입력되지 않았습니다.")

client = OpenAI(api_key=api_key)


def select_excel_file():
    root = tk.Tk()
    root.withdraw()

    file_path = filedialog.askopenfilename(
        title="분석할 엑셀 파일을 선택하세요",
        filetypes=[
            ("Excel files", "*.xlsx *.xls"),
            ("All files", "*.*")
        ]
    )

    return file_path


def find_sales_columns(df):
    product_col = None

    for col in df.columns:
        col_text = str(col).strip()

        if "제품" in col_text or "상품" in col_text or "품목" in col_text:
            product_col = col
            break

    if product_col is None:
        raise ValueError("제품명 컬럼을 찾지 못했습니다.")

    expected_months = [
        "1월", "2월", "3월", "4월", "5월", "6월",
        "7월", "8월", "9월", "10월", "11월", "12월"
    ]

    month_cols = []

    for col in df.columns:
        col_text = str(col).strip()

        if col_text in expected_months:
            month_cols.append(col)

    if not month_cols:
        raise ValueError("1월~12월 형식의 월별 판매량 컬럼을 찾지 못했습니다.")

    return product_col, month_cols


def analyze_sales_table(df, product_col, month_cols):
    for col in month_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    df["총판매량"] = df[month_cols].sum(axis=1)

    top_product_row = df.sort_values("총판매량", ascending=False).iloc[0]

    monthly_total = df[month_cols].sum()
    monthly_total_sorted = monthly_total.sort_values(ascending=False)

    product_total_top10 = (
        df[[product_col, "총판매량"]]
        .sort_values("총판매량", ascending=False)
        .head(10)
    )

    analysis_result = {
        "데이터_구조": "제품명과 1월~12월 판매량이 정리된 월별 판매량 표",
        "전체_제품_수": int(len(df)),
        "전체_판매량": float(df["총판매량"].sum()),
        "가장_많이_팔린_제품": {
            "제품명": str(top_product_row[product_col]),
            "총판매량": float(top_product_row["총판매량"])
        },
        "판매량이_가장_많은_월": {
            "월": str(monthly_total_sorted.index[0]),
            "총판매량": float(monthly_total_sorted.iloc[0])
        },
        "월별_총판매량": {
            str(month): float(value)
            for month, value in monthly_total.items()
        },
        "제품별_총판매량_TOP10": {
            str(row[product_col]): float(row["총판매량"])
            for _, row in product_total_top10.iterrows()
        }
    }

    return analysis_result


def generate_report_with_openai(client, analysis_result):
    prompt = f"""
다음은 엑셀 판매 데이터를 파이썬으로 계산한 결과입니다.

데이터 설명:
- 제품별 1월~12월 판매량 데이터입니다.
- 금액 정보는 없고 판매량 정보만 있습니다.
- 따라서 매출액이 아니라 판매량 기준으로 분석해야 합니다.

작성 조건:
- 한국어로 작성
- 실무 보고서 문체
- 너무 길지 않게 작성
- 자료에 없는 원인은 단정하지 말 것
- 숫자를 근거로 설명할 것
- 문단 제목을 포함할 것

반드시 포함할 내용:
1. 전체 판매량 요약
2. 가장 많이 팔린 제품
3. 판매량이 가장 많았던 월
4. 제품별 판매량 관점에서 주의할 점
5. 월별 판매량 관점에서 주의할 점
6. 추가로 확인하면 좋은 사항

분석 데이터:
{json.dumps(analysis_result, ensure_ascii=False, indent=2)}
"""

    response = client.responses.create(
        model="gpt-4.1-mini",
        input=prompt
    )

    return response.output_text


def main():
    file_path = select_excel_file()

    if not file_path:
        print("파일이 선택되지 않았습니다.")
        return

    df = pd.read_excel(file_path, sheet_name=0)

    product_col, month_cols = find_sales_columns(df)

    analysis_result = analyze_sales_table(df, product_col, month_cols)

    print("\n[파이썬 계산 결과]")
    print(json.dumps(analysis_result, ensure_ascii=False, indent=2))

    print("\n[OpenAI 분석 리포트 생성 중...]")
    report = generate_report_with_openai(client, analysis_result)

    print("\n==============================")
    print("판매 데이터 분석 리포트")
    print("==============================")
    print(report)

    output_path = "판매데이터_분석리포트.txt"

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"\n리포트가 저장되었습니다: {output_path}")


if __name__ == "__main__":
    main()