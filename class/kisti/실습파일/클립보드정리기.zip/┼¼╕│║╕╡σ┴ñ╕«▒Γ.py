"""
클립보드 정리기 (Clipboard Cleaner) v4
====================================
클립보드에 있는 텍스트를 자동으로 정리해주는 스크립트입니다.
실행하면 클립보드 내용을 읽어서 정리한 뒤, 다시 클립보드에 넣어줍니다.

v4 변경사항:
- v3: 클립보드 접근이 "에러"를 낼 때만 재시도 -> 다른 프로그램이 잠깐
  클립보드를 점유했다가 풀리는 경우는 해결됨
- v4: 여기에 추가로, 단축키를 누른 직후 원본 프로그램(브라우저 등)이
  아직 클립보드 쓰기를 "끝내지 못한" 상태에서 우리가 먼저 읽어버리는
  타이밍 문제를 해결. paste()는 에러 없이 그냥 '옛날' 내용을 반환할 수
  있어서, 이 경우는 재시도로 못 잡습니다. 그래서 읽기 전에 아주 짧게
  먼저 대기하는 STARTUP_DELAY를 추가했습니다.

필요 패키지 설치 (VS Code 터미널에서 1회만 실행):
    pip install pyperclip
"""

import re
import sys
import time
import winsound  # 윈도우 전용: 실행 완료 시 소리로 알려주기 위함
import pyperclip


# ------------------------------------------------------------------
# 0. 설정값
#    - STARTUP_DELAY: 스크립트 시작 후, 클립보드를 읽기 전에 기다리는 시간(초)
#      너무 짧으면 여전히 옛날 내용을 읽을 수 있고,
#      너무 길면 "삑" 소리가 늦게 나서 답답하게 느껴질 수 있습니다.
#      0.15초 정도가 반응성과 안정성의 적당한 균형점입니다.
# ------------------------------------------------------------------
STARTUP_DELAY = 0.15


# ------------------------------------------------------------------
# 1. 정리 규칙(rule) 정의
#    - 규칙마다 함수 하나 = "text를 받아서 정리된 text를 반환"하는 구조로 통일
#    - 새로운 문제가 생기면, 이 형식 그대로 함수만 추가하면 됩니다.
# ------------------------------------------------------------------

def remove_double_newline(text: str) -> str:
    """
    1번 규칙: 연속된 빈 줄(엔터 두 번 이상)을 한 번으로 줄인다.
    예) '안녕\n\n반가워' -> '안녕\n반가워'
    """
    return re.sub(r'\n{2,}', '\n', text)


def strip_trailing_spaces(text: str) -> str:
    """
    2번 규칙: 각 줄 끝에 붙는 불필요한 공백(trailing space)을 제거한다.
    """
    lines = text.split('\n')
    cleaned_lines = [line.rstrip() for line in lines]
    return '\n'.join(cleaned_lines)


def collapse_multiple_spaces(text: str) -> str:
    """
    3번 규칙: 단어 사이에 공백이 여러 개 연속되면 1개로 줄인다.
    (줄바꿈 문자는 건드리지 않고, 같은 줄 안의 공백만 정리)
    """
    lines = text.split('\n')
    cleaned_lines = [re.sub(r'[ \t]{2,}', ' ', line) for line in lines]
    return '\n'.join(cleaned_lines)


def remove_leading_trailing_blank_lines(text: str) -> str:
    """
    4번 규칙: 텍스트 맨 앞/뒤에 남아있는 빈 줄을 제거한다.
    """
    return text.strip('\n')


RULES = [
    remove_double_newline,                 # 1. 더블 엔터 제거
    strip_trailing_spaces,                 # 2. 줄 끝 공백 제거
    collapse_multiple_spaces,              # 3. 중복 공백 제거
    remove_leading_trailing_blank_lines,   # 4. 맨 앞/뒤 빈 줄 제거
]


def clean_clipboard_text(text: str) -> str:
    """
    5번 동작: RULES에 등록된 함수들을 순서대로 적용해서
    최종적으로 정리된 텍스트를 반환한다.
    """
    for rule in RULES:
        text = rule(text)
    return text


# ------------------------------------------------------------------
# 2. 클립보드 접근용 재시도 함수
#    - Windows 클립보드는 순간적으로 다른 프로그램이 점유할 수 있어서
#      "에러가 나며" 실패할 수 있습니다. 실패하면 잠깐 쉬었다가 다시 시도합니다.
#    - (이 부분은 v3와 동일 - 에러로 실패하는 경우 대응)
# ------------------------------------------------------------------

def safe_paste(max_attempts: int = 10, delay_sec: float = 0.05) -> str:
    """
    6번 동작: 클립보드 읽기를 최대 max_attempts번까지 재시도한다.
    """
    last_error = None
    for attempt in range(1, max_attempts + 1):
        try:
            return pyperclip.paste()
        except Exception as e:
            last_error = e
            time.sleep(delay_sec)
    raise last_error


def safe_copy(text: str, max_attempts: int = 10, delay_sec: float = 0.05) -> None:
    """
    7번 동작: 클립보드 쓰기를 최대 max_attempts번까지 재시도한다.
    """
    last_error = None
    for attempt in range(1, max_attempts + 1):
        try:
            pyperclip.copy(text)
            return
        except Exception as e:
            last_error = e
            time.sleep(delay_sec)
    raise last_error


def main():
    """
    8번 동작(메인 실행 흐름)
    ① 원본 프로그램이 클립보드 쓰기를 끝낼 시간을 벌기 위해 잠깐 대기 (STARTUP_DELAY)
       -> 바로 이 부분이 "두 번 눌러야 되는" 문제의 핵심 해결책입니다.
    ② 클립보드에서 현재 텍스트를 재시도 로직과 함께 읽는다
    ③ RULES에 따라 정리한다
    ④ 정리된 텍스트를 재시도 로직과 함께 클립보드에 다시 넣는다
    ⑤ 짧은 비프음으로 "정리 완료"를 알린다
    """
    # ① 시작 대기
    time.sleep(STARTUP_DELAY)

    try:
        original = safe_paste()
    except Exception:
        sys.exit(0)

    if not original:
        sys.exit(0)

    cleaned = clean_clipboard_text(original)

    try:
        safe_copy(cleaned)
    except Exception:
        sys.exit(0)

    # ⑤ 완료 알림 (1000Hz, 0.12초 비프음)
    winsound.Beep(1000, 120)


if __name__ == "__main__":
    main()