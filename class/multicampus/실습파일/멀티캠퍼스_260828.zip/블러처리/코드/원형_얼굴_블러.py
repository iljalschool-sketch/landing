"""선택한 사진의 얼굴을 원형 블러 처리합니다.

1. 파일 선택 창에서 처리할 JPG/PNG 파일을 고릅니다.
2. 미리보기에서 블러하지 않을 얼굴(예: 대표, 강사 등)을 클릭합니다.
3. Enter 또는 S를 누르면 저장, Q 또는 Esc를 누르면 해당 파일을 건너뜁니다.

처리 결과는 원본과 같은 폴더에 *_blurred.jpg로 저장됩니다.

"""

from __future__ import annotations

import sys
import shutil
import tempfile
import urllib.request
from pathlib import Path

from typing import Iterable

import cv2
import numpy as np
from PIL import Image
from tkinter import Tk, filedialog


MODEL_URL = (
    "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/"
    "face_detection_yunet_2023mar.onnx"
)
MODEL_NAME = "face_detection_yunet_2023mar.onnx"
PREVIEW_MAX_WIDTH = 1500
PREVIEW_MAX_HEIGHT = 950


def get_model_path() -> Path:
    """모델이 없으면 내려받고, OpenCV용 ASCII 경로에 복사합니다."""
    model_path = Path(__file__).with_name(MODEL_NAME)
    if not model_path.exists():
        print("얼굴 검출 모델을 다운로드합니다. 인터넷 연결이 필요합니다.")
        urllib.request.urlretrieve(MODEL_URL, model_path)
    # 일부 Windows OpenCV 빌드는 한글 경로의 ONNX 파일을 직접 읽지 못합니다.
    # 실행할 때만 임시 폴더의 영문 경로에 복사해 모델을 불러옵니다.
    cache_path = Path(tempfile.gettempdir()) / MODEL_NAME
    if not cache_path.exists() or cache_path.stat().st_size != model_path.stat().st_size:
        shutil.copy2(model_path, cache_path)
    return cache_path


def choose_files() -> tuple[str, ...]:
    root = Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    files = filedialog.askopenfilenames(
        title="원형 블러 처리할 사진 선택",
        filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.webp"), ("All files", "*.*")],
    )
    root.destroy()
    return files


def detect_faces(rgb: np.ndarray, detector: cv2.FaceDetectorYN) -> list[tuple[int, int, int, int]]:
    height, width = rgb.shape[:2]
    scale = min(1.0, 3000.0 / max(width, height))
    reduced = cv2.resize(rgb, (round(width * scale), round(height * scale)))
    detector.setInputSize((reduced.shape[1], reduced.shape[0]))
    _, faces = detector.detect(cv2.cvtColor(reduced, cv2.COLOR_RGB2BGR))
    if faces is None:
        return []
    return [tuple((face[:4] / scale).astype(int)) for face in faces]


def preview_scale(width: int, height: int) -> float:
    return min(1.0, PREVIEW_MAX_WIDTH / width, PREVIEW_MAX_HEIGHT / height)


def choose_exclusions(rgb: np.ndarray, boxes: list[tuple[int, int, int, int]]) -> set[int] | None:
    """클릭으로 제외할 얼굴을 고릅니다. None은 파일 건너뛰기입니다."""
    height, width = rgb.shape[:2]
    scale = preview_scale(width, height)
    display = cv2.resize(rgb, (round(width * scale), round(height * scale)))
    excluded: set[int] = set()
    window = "Click faces to KEEP clear | Enter/S: save | Q/Esc: skip"

    def draw() -> np.ndarray:
        canvas = display.copy()
        for index, (x, y, face_width, face_height) in enumerate(boxes):
            color = (0, 220, 0) if index in excluded else (255, 0, 0)
            cv2.ellipse(
                canvas,
                (round((x + face_width / 2) * scale), round((y + face_height / 2) * scale)),
                (max(2, round(face_width * 0.70 * scale)), max(2, round(face_height * 0.70 * scale))),
                0,
                0,
                360,
                color,
                2,
            )
        return cv2.cvtColor(canvas, cv2.COLOR_RGB2BGR)

    def on_mouse(event: int, mouse_x: int, mouse_y: int, _flags: int, _param: object) -> None:
        if event != cv2.EVENT_LBUTTONDOWN:
            return
        for index, (x, y, face_width, face_height) in enumerate(boxes):
            center_x = (x + face_width / 2) * scale
            center_y = (y + face_height / 2) * scale
            radius_x = max(1, face_width * 0.78 * scale)
            radius_y = max(1, face_height * 0.78 * scale)
            if ((mouse_x - center_x) / radius_x) ** 2 + ((mouse_y - center_y) / radius_y) ** 2 <= 1:
                if index in excluded:
                    excluded.remove(index)
                else:
                    excluded.add(index)
                break

    cv2.namedWindow(window, cv2.WINDOW_AUTOSIZE)
    cv2.setMouseCallback(window, on_mouse)
    while True:
        cv2.imshow(window, draw())
        key = cv2.waitKey(30) & 0xFF
        if key in (13, ord("s"), ord("S")):
            cv2.destroyWindow(window)
            return excluded
        if key in (27, ord("q"), ord("Q")):
            cv2.destroyWindow(window)
            return None


def circular_blur(rgb: np.ndarray, boxes: Iterable[tuple[int, int, int, int]], excluded: set[int]) -> np.ndarray:
    height, width = rgb.shape[:2]
    mask = np.zeros((height, width), dtype=np.uint8)
    for index, (x, y, face_width, face_height) in enumerate(boxes):
        if index in excluded:
            continue
        center = (x + face_width // 2, y + face_height // 2)
        radius = round(max(face_width, face_height) * 0.72)
        cv2.circle(mask, center, radius, 255, thickness=-1)
    alpha = cv2.GaussianBlur(mask, (0, 0), sigmaX=12, sigmaY=12).astype(np.float32) / 255.0
    blurred = cv2.GaussianBlur(rgb, (0, 0), sigmaX=18, sigmaY=18)
    return (rgb * (1 - alpha[..., None]) + blurred * alpha[..., None]).astype(np.uint8)


def process_file(path: Path, detector: cv2.FaceDetectorYN) -> None:
    image = Image.open(path)
    exif = image.info.get("exif")
    rgb = np.asarray(image.convert("RGB"))
    boxes = detect_faces(rgb, detector)
    print(f"{path.name}: 얼굴 {len(boxes)}개 감지")
    excluded = choose_exclusions(rgb, boxes)
    if excluded is None:
        print(f"{path.name}: 건너뜀")
        return
    output = circular_blur(rgb, boxes, excluded)
    destination = path.with_name(f"{path.stem}_blurred.jpg")
    Image.fromarray(output).save(destination, "JPEG", quality=95, subsampling=0, exif=exif or b"")
    print(f"저장 완료: {destination}")


def main() -> None:
    print(__doc__, flush=True)
    paths = [Path(item) for item in choose_files()]
    if not paths:
        return
    detector = cv2.FaceDetectorYN.create(str(get_model_path()), "", (320, 320), 0.72, 0.30, 5000)
    for path in paths:
        try:
            process_file(path, detector)
        except Exception as error:
            print(f"{path.name}: 처리 실패 - {error}")
    print("작업이 끝났습니다. 창을 닫으려면 Enter를 누르세요.")
    input()


if __name__ == "__main__":
    main()
